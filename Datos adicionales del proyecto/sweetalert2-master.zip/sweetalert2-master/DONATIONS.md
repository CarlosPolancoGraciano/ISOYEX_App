We would like to thank everyone who contributed to this library. If you find our library useful and wish to support as well, you can do so [through Patreon](https://www.patreon.com/limonte) or directly [through PayPal](https://www.paypal.me/limonte/5eur). Your contribution will be greatly appreciated!


# Patrons

- **[Olli Murto](https://www.patreon.com/user/?u=9095640)** ($1 per month)

- **[Samuel Georges](https://www.patreon.com/daftspunk)**, the creator of [October CMS](https://github.com/octobercms/october) ($1 per month)

- **[Albert Møller Nielsen](https://www.patreon.com/user?u=4221410)** ($1 per month)


# Donors

- **Mustafa Khader** (5 USD)

- **Quentin Le Doledec** (5 EUR)

- **[Cassiano Montanari](https://github.com/cassianomon)** (10 BRL)

- **[VEI Hosting](http://www.veihosting.com/)** (20 USD)

- **Daniel Seuffer** (10 EUR)

    > Thx for this very sweet alert!! And the continuous support. :-)

- **Legoman99573** (0,20 EUR)

    > I dont have much, but I can say that SweetAlert2 is badass and have used it. Here is what I still have left in my paypal balance. Like to see more features in the future to play with.

- **Munsifali Rashid** (5 USD)

- **Danny Lankar** (25 USD)

    > You should be selling this product. Love it, thank you!

- **Mapcom Internet Technologies** (10 AUD)

- **Pawel Terebinski** (5 EUR)

- **Morgan Touverey** (10 EUR)

    > From [@toverux](github.com/toverux) with love!

- **Singdavid Srun** (2 EUR)

- **Victor Felipe De Freitas** (10 BRL)

- **Diego Liz Arrazao** (5 BRL)

- **Lindauson Hazell** (5 EUR)

- **Quipro** (5 USD)

- **David Langheiter** (5 EUR)
